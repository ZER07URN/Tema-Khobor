 <style type="text/css">
	button.btn { margin-left: 0px; }
	#collapse2 { margin-top: 5px; }
	button[aria-expanded=true] .fa-chevron-down {
	   display: none;
	}
	button[aria-expanded=false] .fa-chevron-up {
	   display: none;
	}
</style>
                        <div class="single-sidebar col-lg-12 col-md-6 col-12"  style="margin-bottom:10px;">

                            <!-- Sidebar Block Wrapper -->
                            <div class="sidebar-block-wrapper">

                                <!-- Sidebar Block Head Start -->
                                <div class="head video-head">

                                    <!-- Title -->
                                    <h4 class="title"> <?="Lokasi Kantor ".ucwords($this->setting->sebutan_desa)?></h4>

                                </div><!-- Sidebar Block Head End -->

                                <!-- Sidebar Block Body Start -->
                                <div class="body">
								<!-- widget Peta Wilayah Desa -->

          
<!-- widget Peta Lokasi Kantor Desa -->



    <div id="map_canvas" style="height:200px;"></div>
    <button class="btn btn-success btn-block"><a href="https://www.openstreetmap.org/#map=15/<?=$data_config['lat']."/".$data_config['lng']?>" style="color:#fff;" target="_blank">Buka Peta</a></button>
		<button class="btn btn-success btn-block" data-toggle="collapse" data-target="#collapse2" aria-expanded="false">
			Detail
      <i class="fa fa-chevron-up pull-right"></i>
      <i class="fa fa-chevron-down pull-right"></i>
		</button>
		<div id="collapse2" class="panel-collapse collapse">
			<div class="info-desa">
				<table width="100%">
					<tr style="border-bottom: 1px solid #ddd;">
						<td class="label-info-desa" width="25%" height="30px">Alamat</td>
						<td class="isi-info-desa" width="70%"><?php echo $desa['alamat_kantor']?></td>
					</tr>
					<tr style="border-bottom: 1px solid #ddd;">
						<td class="label-info-desa" width="25%" height="30px"><?php echo ucwords($this->setting->sebutan_desa)." "?></td>
						<td class="isi-info-desa" width="70%" height="30px"><?php echo $desa['nama_desa']?></td>
					</tr>
					<tr style="border-bottom: 1px solid #ddd;">
						<td class="label-info-desa" width="25%" height="30px"><?php echo ucwords($this->setting->sebutan_kecamatan)?></td>
						<td class="isi-info-desa" width="70%" height="30px"><?php echo $desa['nama_kecamatan']?></td>
					</tr>
					<tr style="border-bottom: 1px solid #ddd;">
						<td class="label-info-desa" width="25%" height="30px"><?php echo ucwords($this->setting->sebutan_kabupaten)?></td>
						<td class="isi-info-desa" width="70%" height="30px"><?php echo $desa['nama_kabupaten']?></td>
					</tr>
					<tr style="border-bottom: 1px solid #ddd;">
						<td class="label-info-desa" width="25%" height="30px">Kodepos</td>
						<td class="isi-info-desa" width="70%" height="30px"><?php echo $desa['kode_pos']?></td>
					</tr>
					<tr style="border-bottom: 1px solid #ddd;">
						<td class="label-info-desa" width="25%" height="30px">Telepon</td>
						<td class="isi-info-desa" width="70%" height="30px"><?php echo $desa['telepon']?></td>
					</tr>
					<tr>
						<td class="label-info-desa" width="25%" height="40px">Email</td>
						<td class="isi-info-desa" width="70%" height="40px"><?php echo $desa['email_desa']?></td>
					</tr>
				</table>
			</div>
		</div>
	
 
                                </div><!-- Sidebar Block Body End -->

                            </div>

                        </div>


     




	





<script>
	//Jika posisi kantor desa belum ada, maka posisi peta akan menampilkan seluruh Indonesia
	<?php if (!empty($data_config['lat']) && !empty($data_config['lng'])): ?>
    var posisi = [<?=$data_config['lat'].",".$data_config['lng']?>];
    var zoom = <?=$data_config['zoom'] ?: 10?>;
	<?php else: ?>
    var posisi = [-1.0546279422758742,116.71875000000001];
    var zoom = 10;
	<?php endif; ?>

	var lokasi_kantor = L.map('map_canvas').setView(posisi, zoom);

	//Menampilkan BaseLayers Peta
	var defaultLayer = L.tileLayer.provider('OpenStreetMap.Mapnik').addTo(lokasi_kantor);

	var baseLayers = {
		'OpenStreetMap': defaultLayer,
		'Mapbox Streets Satellite' : L.tileLayer('https://api.mapbox.com/v4/mapbox.streets-satellite/{z}/{x}/{y}@2x.png?access_token=<?=$this->setting->google_key?>', {attribution: '<a href="https://www.mapbox.com/about/maps">© Mapbox</a> <a href="https://openstreetmap.org/copyright">© OpenStreetMap</a>'}),
	};

	L.control.layers(baseLayers, null, {position: 'topright', collapsed: true}).addTo(lokasi_kantor);

	//Jika posisi kantor desa belum ada, maka posisi peta akan menampilkan seluruh Indonesia
	<?php if (!empty($data_config['lat']) && !empty($data_config['lng'])): ?>
    var kantor_desa = L.marker(posisi).addTo(lokasi_kantor);
	<?php endif; ?>
</script>
