var api_key = 'AIzaSyAsvJPKTArFviBbDntKU4sHxkl8fYrj1uM';

/* Initialize all the player in the page with default options*/
$('.RYPP').rypp(api_key, {
    autoplay: true,

});