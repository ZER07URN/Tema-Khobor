<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<script src="<?= base_url("$this->theme_folder/$this->theme/assets/js/plugins.js")?>"></script>
<!--
<script src="<?= base_url("$this->theme_folder/$this->theme/assets/js/rypp.js")?>"></script>
<script src="<?= base_url("$this->theme_folder/$this->theme/assets/js/ytp-playlist.js")?>"></script>-->
<script src="<?= base_url("$this->theme_folder/$this->theme/assets/js/main.js")?>"></script>






