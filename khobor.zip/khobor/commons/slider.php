<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
 <?php 
		if ((empty($_GET['cari'])) && ((count($slide_galeri)>0 || count($slide_artikel)>0)) AND $this->uri->segment(2) != 'kategori' 
		 ) {?>
 
    <!-- Hero Section Start -->
    <div class="hero-section section mt-30 mb-30">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="row row-1">

                        <div class="order-lg-2 col-lg-6 col-12">
                            
                            <!-- Hero Post Slider Start -->
                            <div class="post-carousel-1">

                     <?php if($slider_gambar['gambar']) : ?>
					 <?php foreach($slider_gambar['gambar'] as $data) : ?>
				<?php $img = $slider_gambar['lokasi'] . 'sedang_' . $data['gambar']; ?>
				<?php if(is_file($img)) : ?>
					            <!-- Overlay Post Start -->
                                <div class="post post-large post-overlay hero-post">
                                    <div class="post-wrap">

                                        <!-- Image -->
                                 

			
					<div class="item">
						<img data-src="<?= base_url($img) ?>" alt="<?= $data['judul'] ?>" class="img-fluid lazy">
					</div>
		


                                        <!-- Category -->
                                        <a href="#" class="category politic">Politic</a>

                                        <!-- Content -->
                                        <div class="content">

                                            <!-- Title -->
                                            <h2 class="title"><a href="post-details.html">Political Allies Are Not Friend.</a></h2>

                                            <!-- Meta -->
                                            <div class="meta fix">
                                                <span class="meta-item date"><i class="fa fa-clock-o"></i>10 March 2017</span>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div><!-- Overlay Post End -->
										<?php endif ?>
			<?php endforeach ?>
                          <?php endif ?>      
                               
                            </div><!-- Hero Post Slider End -->
                            
                        </div>

                        <div class="order-lg-1 col-lg-3 col-12">
                            <div class="row row-1">

                                <!-- Overlay Post Start -->
                                <div class="post post-overlay hero-post col-lg-12 col-md-6 col-12">
                                    <div class="post-wrap">

                                        <!-- Image -->
                                        <div class="image"><img src="img/post/post-1.jpg" alt="post"></div>

                                        <!-- Category -->
                                        <a href="#" class="category travel">travel</a>

                                        <!-- Content -->
                                        <div class="content">

                                            <!-- Title -->
                                            <h4 class="title"><a href="post-details.html">Hynpodia helps fmale travelers find health.</a></h4>

                                            <!-- Meta -->
                                            <div class="meta fix">
                                                <span class="meta-item date"><i class="fa fa-clock-o"></i>10 March 2017</span>
                                            </div>

                                        </div>

                                    </div>
                                </div><!-- Overlay Post End -->

                                <!-- Overlay Post Start -->
                                <div class="post post-overlay hero-post col-lg-12 col-md-6 col-12">
                                    <div class="post-wrap">

                                        <!-- Image -->
                                        <div class="image"><img src="img/post/post-2.jpg" alt="post"></div>

                                        <!-- Category -->
                                        <a href="#" class="category fashion">Fashion</a>

                                        <!-- Content -->
                                        <div class="content">

                                            <!-- Title -->
                                            <h4 class="title"><a href="post-details.html">Fashion is about some thing that comes from with in you.</a></h4>

                                            <!-- Meta -->
                                            <div class="meta fix">
                                                <span class="meta-item date"><i class="fa fa-clock-o"></i>10 March 2017</span>
                                            </div>

                                        </div>

                                    </div>
                                </div><!-- Overlay Post End -->

                            </div>
                        </div>

                        <div class="order-lg-3 col-lg-3 col-12">
                            <div class="row row-1">

                                <!-- Overlay Post Start -->
                                <div class="post post-overlay gradient-overlay-1 hero-post col-lg-12 col-md-6 col-12">
                                    <div class="post-wrap">

                                        <!-- Image -->
                                        <div class="image"><img src="img/post/post-5.jpg" alt="post"></div>

                                        <!-- Category -->
                                        <a href="#" class="category sports">Sports</a>

                                        <!-- Content -->
                                        <div class="content">

                                            <!-- Title -->
                                            <h4 class="title"><a href="post-details.html">Australia announced squad for Bangladesh tour.</a></h4>

                                            <!-- Meta -->
                                            <div class="meta fix">
                                                <span class="meta-item date"><i class="fa fa-clock-o"></i>10 March 2017</span>
                                            </div>

                                        </div>

                                    </div>
                                </div><!-- Overlay Post End -->

                                <!-- Overlay Post Start -->
                                <div class="post post-overlay gradient-overlay-1 hero-post col-lg-12 col-md-6 col-12">
                                    <div class="post-wrap" style="width:">

                                        <!-- Image -->
                                        <div class="image"><img src="img/post/post-6.jpg"  alt="post"></div>

                                        <!-- Category -->
                                        <a href="#" class="category gadgets">Gadgets</a>

                                        <!-- Content -->
                                        <div class="content">

                                            <!-- Title -->
                                            <h4 class="title"><a href="post-details.html">Apple, time to IOS With macos.</a></h4>

                                            <!-- Meta -->
                                            <div class="meta fix">
                                                <span class="meta-item date"><i class="fa fa-clock-o"></i>10 March 2017</span>
                                            </div>

                                        </div>

                                    </div>
                                </div><!-- Overlay Post End -->

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div><!-- Hero Section End -->
	
	<?php	}
	?>